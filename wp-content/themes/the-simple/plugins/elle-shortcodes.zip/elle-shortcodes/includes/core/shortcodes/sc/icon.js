scnShortcodeMeta={
	attributes:[
       {
			label:"Color",
			id:"color",
			help:"Select the color for your icon"
			
        },
        {
			label:"Size",
			id:"size",
			help:"Type the size in px for the icon",
        },
                        
      ],
		
		shortcode:"icon"
}; 