<?php
/**
 * Plugin Name: Elle Framework
 * Plugin URI: http://ellethemes.com
 * Description: Elle Themes Framework
 * Version: 1.1.0
 * Author: Elle
 * Author URI: http://ellethemes.com
 * License: GPL2
 */
 
 // don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
/**
 * Current version
 */
if ( ! defined( 'ELLE_VERSION' ) ) {

	define( 'ELLE_VERSION', '1.0.1' );
}


class ElleFramework{
    
	    
        public function __construct(){

        	$this->dir = dirname(__FILE__);

        	if(file_exists( get_template_directory(). '/includes/core/simple_metaboxes.php' )){
	    		require_once(get_template_directory().'/includes/core/simple_metaboxes.php');

		    	// The loader will load all of the extensions automatically based on your $redux_opt_name
				require_once($this->dir. '/admin/loader/loader.php');
			}	

	    	/* -------------------- Load Simple Import/Export ------------------ */
		    add_filter( "redux/simple_redata/field/class/codeless_import", array($this, "simple_import_export_load" ));
			

			/* -------------------- End Load Simple Import/Export -------------- */

			if ( !class_exists( 'ReduxFramework' ) && file_exists(  $this->dir. '/admin/framework.php' ) ) {
			    require_once(  $this->dir. '/admin/framework.php' );
			}


			if ( !isset( $redux_demo ) && file_exists( get_template_directory(). '/includes/core/simple_options.php' ) ) {
			    require_once(  get_template_directory(). '/includes/core/simple_options.php' );
			}

			require_once( $this->dir.'/admin/inc/fields/codeless_import/import_export.php');
	    }

	    public function simple_import_export_load($field) {
			    return  $this->dir.'/admin/inc/fields/codeless_import/codeless_import.php'; 
		}
}



new ElleFramework();