<?php
/*
Plugin Name: Elle Custom Post Types
Plugin URI: http://ellethemes.co
Description: Create required custom post types, portfolio, staff, testimonial etc
Author: Eldo Roshi
Author URI: http://ellethemes.co
Version: 1.0.0
Text Domain: elle-custom-posts
License: GPL version 2 or later - http://www.gnu.org/licenses/old-licenses/gpl-2.0.html
*/


/* Register Portfolio Post Type */

add_action('init', 'portfolio_register', 1);

function portfolio_register() 

{

	global $simple_redata;

	$labels = array(

		'name' => _x('Portfolio Items', 'post type general name', 'simple'),

		'singular_name' => _x('Portfolio Entry', 'post type singular name', 'simple'),

		'add_new' => _x('Add New', 'portfolio', 'simple'),

		'add_new_item' => __('Add New Portfolio Entry', 'simple'),

		'edit_item' => __('Edit Portfolio Entry', 'simple'),

		'new_item' => __('New Portfolio Entry', 'simple'),

		'view_item' => __('View Portfolio Entry', 'simple'),

		'search_items' => __('Search Portfolio Entries', 'simple'),

		'not_found' =>  __('No Portfolio Entries found', 'simple'),

		'not_found_in_trash' => __('No Portfolio Entries found in Trash', 'simple'), 

		'parent_item_colon' => ''

	);

	

	$slugRule = (isset($simple_redata["portfolio_slug"]) ? $simple_redata["portfolio_slug"] : '');

	

	$args = array(

		'labels' => $labels,

		'public' => true,

		'show_ui' => true,

		'capability_type' => 'post',

		'hierarchical' => false,

		'rewrite' => array('slug'=>$slugRule,'with_front'=>true),

		'query_var' => true,

		'show_in_nav_menus'=> false,

		'supports' => array('title','thumbnail','excerpt','editor','comments')

	);

	

	

	

	register_post_type( 'portfolio' , $args );

	

	

	register_taxonomy("portfolio_entries", 

		array("portfolio"), 

		array(	"hierarchical" => true, 

		"label" => "Portfolio Categories", 

		"singular_label" => "Portfolio Categories", 

		"rewrite" => true,

		"query_var" => true

	));  

}



add_filter("manage_edit-portfolio_columns", "prod_edit_columns");

add_action("manage_posts_custom_column",  "prod_custom_columns");


function prod_edit_columns($columns)

{

	$newcolumns = array(

		"cb" => "<input type=\"checkbox\" />",

		

		"title" => "Title",

		"portfolio_entries" => "Categories"

	);

	

	$columns= array_merge($newcolumns, $columns);

	

	return $columns;

}


function prod_custom_columns($column)

{

	global $post;

	switch ($column)

	{

	

		case "description":

		

		break;

		case "price":

		

		break;

		case "portfolio_entries":

		echo get_the_term_list($post->ID, 'portfolio_entries', '', ', ','');

		break;

	}

}

/**** End Register Portfolio Post Types ******/

/**** Staff Post Type Register  *****/

add_action('init', 'staff_register', 3);

function staff_register() 
{

	$labels = array(
		'name' => _x('Team', 'post type general name', 'simple'),
		'singular_name' => _x('Staff Entry', 'post type singular name', 'simple'),
		'add_new' => _x('Add New', 'staff', 'simple'),
		'add_new_item' => __('Add New Staff Entry', 'simple'),
		'edit_item' => __('Edit Staff Entry', 'simple'),
		'new_item' => __('New Staff Entry', 'simple'),
		'view_item' => __('View Staff Entry', 'simple'),
		'search_items' => __('Search Staff Entries', 'simple'),
		'not_found' =>  __('No Staff Entries found', 'simple'),
		'not_found_in_trash' => __('No Staff Entries found in Trash', 'simple'), 
		'parent_item_colon' => ''
	);
	
	$slugRule = "staff_trusted";
	
	$args = array(
		'labels' => $labels,
		'public' => true,
		'show_ui' => true,
		'capability_type' => 'post',
		'hierarchical' => false,
		'rewrite' => array('slug'=>$slugRule,'with_front'=>true),
		'query_var' => true,
		'show_in_nav_menus'=> false,
		'supports' => array('title','thumbnail','editor')
	);
	
	
	
	register_post_type( 'staff' , $args );
	
	
	register_taxonomy("staff_entries", 
		array("staff"), 
		array(	"hierarchical" => true, 
		"label" => "Staff Categories", 
		"singular_label" => "Staff Categories", 
		"rewrite" => true,
		"query_var" => true
	));  
}

add_filter("manage_edit-staff_columns", "prod_edit_staff_columns");
add_action("manage_posts_custom_column",  "prod_custom_staff_columns");


function prod_edit_staff_columns($columns)
{
	$newcolumns = array(
		"cb" => "<input type=\"checkbox\" />",
		
		"title" => "Title",
		"staff_entries" => "Categories"
	);
	
	$columns= array_merge($newcolumns, $columns);
	
	return $columns;
}

function prod_custom_staff_columns($column)
{
	global $post;
	switch ($column)
	{
		
	
		case "description":
		
		break;
		case "price":
		
		break;
		case "staff_entries":
		echo get_the_term_list($post->ID, 'staff_entries', '', ', ','');
		break;
	}
}
/**** End Staff Post Type Register  *****/


/**** Faq custom post type register ****/


add_action('init', 'faq_register', 4);


function faq_register() 

{



	$labels = array(

		'name' => _x('Faq', 'post type general name','simple'),

		'singular_name' => _x('Faq Entry', 'post type singular name', 'simple'),

		'add_new' => _x('Add New', 'faq', 'simple'),

		'add_new_item' => __('Add New Faq Entry', 'simple'),

		'edit_item' => __('Edit Faq Entry', 'simple'),

		'new_item' => __('New Faq Entry', 'simple'),

		'view_item' => __('View Faq Entry', 'simple'),

		'search_items' => __('Search Faq Entries', 'simple'),

		'not_found' =>  __('No Faq Entries found', 'simple'),

		'not_found_in_trash' => __('No Faq Entries found in Trash', 'simple'), 

		'parent_item_colon' => ''

	);

	

	$slugRule = "Faq_quare";

	

	$args = array(

		'labels' => $labels,

		'public' => true,

		'show_ui' => true,

		'capability_type' => 'post',

		'hierarchical' => false,

		'rewrite' => array('slug'=>$slugRule,'with_front'=>true),

		'query_var' => true,

		'show_in_nav_menus'=> false,

		'supports' => array('title','thumbnail','editor')

	);

	

	

	

	register_post_type( 'faq' , $args );

	

	

	register_taxonomy("faq_entries", 

		array("faq"), 

		array(	"hierarchical" => true, 

		"label" => "Faq Categories", 

		"singular_label" => "Faq Categories", 

		"rewrite" => true,

		"query_var" => true

	));  

}



add_filter("manage_edit-faq_columns", "prod_edit_faq_columns");

add_action("manage_posts_custom_column",  "prod_custom_faq_columns");


function prod_edit_faq_columns($columns)

{

	$newcolumns = array(

		"cb" => "<input type=\"checkbox\" />",

		

		"title" => "Title",

		"faq_entries" => "Categories"

	);

	

	$columns= array_merge($newcolumns, $columns);

	

	return $columns;

}


function prod_custom_faq_columns($column)

{

	global $post;

	switch ($column)

	{

		

	

		case "description":

		

		break;

		case "price":

		

		break;

		case "faq_entries":

		echo get_the_term_list($post->ID, 'faq_entries', '', ', ','');

		break;

	}

}


/**** Faq custom post type register ****/


/**** Testimonial custom post type register ****/

add_action('init', 'testimonial_register', 1);


function testimonial_register() 

{



	$labels = array(

		'name' => _x('Testimonials', 'post type general name', 'simple'),

		'singular_name' => _x('Testimonial Entry', 'post type singular name', 'simple'),

		'add_new' => _x('Add New', 'testimonial', 'simple'),

		'add_new_item' => __('Add New Testimonial Entry', 'simple'),

		'edit_item' => __('Edit Testimonial Entry', 'simple'),

		'new_item' => __('New Testimonial Entry', 'simple'),

		'view_item' => __('View Testimonial Entry', 'simple'),

		'search_items' => __('Search Testimonial Entries', 'simple'),

		'not_found' =>  __('No Testimonial Entries found', 'simple'),

		'not_found_in_trash' => __('No Testimonial Entries found in Trash', 'simple'), 

		'parent_item_colon' => ''

	);

	

	$slugRule = "testimonial_trusted";

	

	$args = array(

		'labels' => $labels,

		'public' => true,

		'show_ui' => true,

		'capability_type' => 'post',

		'hierarchical' => false,

		'rewrite' => array('slug'=>$slugRule,'with_front'=>true),

		'query_var' => true,

		'show_in_nav_menus'=> false,

		'supports' => array('title','thumbnail','editor')

	);

	

	

	

	register_post_type( 'testimonial' , $args );

	

	

	register_taxonomy("testimonial_entries", 

		array("testimonial"), 

		array(	"hierarchical" => true, 

		"label" => "Testimonial Categories", 

		"singular_label" => "Testimonial Categories", 

		"rewrite" => true,

		"query_var" => true

	));  

}



add_filter("manage_edit-testimonial_columns", "prod_edit_testimonial_columns");

add_action("manage_posts_custom_column",  "prod_custom_testimonial_columns");


function prod_edit_testimonial_columns($columns)

{

	$newcolumns = array(

		"cb" => "<input type=\"checkbox\" />",

		"title" => "Title",

		"testimonial_entries" => "Categories"

	);

	

	$columns= array_merge($newcolumns, $columns);

	

	return $columns;

}


function prod_custom_testimonial_columns($column)

{

	global $post;

	switch ($column)

	{

		

	

		case "description":

		

		break;

		case "price":

		

		break;

		case "testimonial_entries":

		echo get_the_term_list($post->ID, 'testimonial_entries', '', ', ','');

		break;

	}

}

/**** End Testimonial custom post type register ****/


/**** Simple Slider custom post types ****/

add_action('init', 'simple_slider_register', 1);


function simple_slider_register() 

{



	$labels = array(

		'name' => _x('Slides', 'post type general name', 'simple'),

		'all_items'	=> __('Slides','simple' ),

		'singular_name' => _x('Slide', 'post type singular name', 'simple'),

		'menu_name'	=> __('Simple Slider','simple' ),

		'add_new' => _x('Add New Slide', 'slide', 'simple'),

		'add_new_item' => __('Add New Slide', 'simple'),

		'edit_item' => __('Edit Slide', 'simple'),

		'new_item' => __('New Slide', 'simple'),

		'view_item' => __('View Slide', 'simple'),

		'search_items' => __('Search Slides', 'simple'),

		'not_found' =>  __('No Slides found', 'simple'),

		'not_found_in_trash' => __('No Slides found in Trash', 'simple'), 

		'parent_item_colon' => ''

	);



	$args = array(

		'labels' => $labels,

		'public' => true,

		'show_ui' => true,

		'capability_type' => 'post',

		'hierarchical' => false,

		'rewrite' => array('slug'=>'slides','with_front'=>true),

		'query_var' => true,

		'show_in_nav_menus'=> false,

		'supports' => array('title')

	);

	

	

	

	register_post_type( 'slide' , $args );

	

	$labels = array(
			
			'menu_name' => __( 'Sliders','simple' ),

			'name' => __( 'Sliders', 'taxonomy general name', 'simple' ),

			'singular_name' => __( 'Slider', 'taxonomy singular name', 'simple' ),

			'all_items' => __( 'All Sliders','simple' ),

			'search_items' =>  __( 'Search Sliders','simple' ),

			'parent_item' => __( 'Parent Slider','simple' ),

			'parent_item_colon' => __( 'Parent Slider:','simple' ),

			'update_item' => __( 'Update Slider','simple' ),

			'add_new_item' => __( 'Add New Slider','simple' ),

			'edit_item' => __( 'Edit Slider','simple' ), 

			'new_item_name' => __( 'New Slider Name','simple' )

			
	 );     

	register_taxonomy("slider", 

		array("slide"), 

		array(	"hierarchical" => true, 

		"labels" => $labels, 

		"singular_label" => "Slider", 

		"rewrite" => true,

		"query_var" => true

	));  

}



add_filter("manage_edit-slide_columns", "slide_edit_columns");

add_action("manage_posts_custom_column",  "slide_custom_columns");



function slide_edit_columns($columns)

{

	$newcolumns = array(

		"cb" => "<input type=\"checkbox\" />",

		

		"title" => "Title",

		"slides" => "Sliders"

	);

	

	$columns= array_merge($newcolumns, $columns);

	

	return $columns;

}



/**

 * prod_custom_columns()

 * 

 * @param mixed $column

 * @return

 */

function slide_custom_columns($column)

{

	global $post;

	switch ($column)

	{

	

		case "description":

		

		break;

		case "price":

		

		break;

		case "slider":

		echo get_the_term_list($post->ID, 'slider', '', ', ','');

		break;

	}

}

?>